create definer = root@localhost trigger before_delete_role_from_project
    before delete
    on rolesutilisateurprojet
    for each row
BEGIN
    DELETE FROM sprintbacklog
    WHERE IdU = OLD.IdU
      AND IdT IN (
        SELECT IdT
        FROM taches
        WHERE IdP = OLD.IdP
    );
END;

