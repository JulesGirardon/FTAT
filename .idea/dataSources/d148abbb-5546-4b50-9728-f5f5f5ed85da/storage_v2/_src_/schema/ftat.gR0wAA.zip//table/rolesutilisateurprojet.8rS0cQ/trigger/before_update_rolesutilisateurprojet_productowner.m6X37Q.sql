create definer = root@localhost trigger before_update_rolesutilisateurprojet_ProductOwner
    before update
    on rolesutilisateurprojet
    for each row
BEGIN
    DECLARE count_roles INT;

    IF NEW.IdR = getIdRole('Product Owner') THEN
        SELECT COUNT(*)
        INTO count_roles
        FROM rolesutilisateurprojet AS rup
        WHERE rup.IdP = NEW.IdP
          AND rup.IdR = getIdRole('Product Owner');

        IF count_roles > 0 THEN
            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT = 'Scrum Master déjà existant pour ce projet !';
        END IF;
    END IF;
END;

