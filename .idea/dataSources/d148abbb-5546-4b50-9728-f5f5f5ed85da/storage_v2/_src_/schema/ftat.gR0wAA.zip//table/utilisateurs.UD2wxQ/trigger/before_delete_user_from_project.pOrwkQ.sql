create definer = root@localhost trigger before_delete_user_from_project
    before delete
    on utilisateurs
    for each row
BEGIN
    DELETE FROM sprintbacklog
    WHERE IdU = OLD.IdU;
END;

