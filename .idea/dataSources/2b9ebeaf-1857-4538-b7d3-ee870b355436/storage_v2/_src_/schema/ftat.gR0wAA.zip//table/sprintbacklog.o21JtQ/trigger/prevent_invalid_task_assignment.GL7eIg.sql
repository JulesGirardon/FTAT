create definer = root@localhost trigger prevent_invalid_task_assignment
    before insert
    on sprintbacklog
    for each row
BEGIN
  DECLARE team_id_of_user SMALLINT;
  
  -- Récupère le team ID de l'utilisateur assigné à la tache
  SELECT IdEq INTO team_id_of_user
  FROM utilisateurs
  WHERE IdU = NEW.IdU;

  -- Si la team de l'utilisateur ne correspond pas à la team assignée à la tache, empêche l'assignation
  IF team_id_of_user != (SELECT IdEq FROM taches WHERE IdT = NEW.IdT) THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = "Erreur: L'Utilisateur n'appartient pas à la même équipe que la tâche.";
  END IF;
END;

