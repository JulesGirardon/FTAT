create definer = root@localhost trigger check_team_velocity
    before insert
    on sprints
    for each row
BEGIN
  -- Vérifier que la vélocité de l'équipe est positive
  IF NEW.VelociteEqPrj < 0 THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = "Erreur : La vélocité d'un sprint ne peut pas etre négatif.";
  END IF;
END;

