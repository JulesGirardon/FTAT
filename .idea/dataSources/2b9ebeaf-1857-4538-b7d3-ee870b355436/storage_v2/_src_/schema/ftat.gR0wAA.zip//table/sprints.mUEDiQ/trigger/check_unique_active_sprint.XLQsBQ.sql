create definer = root@localhost trigger check_unique_active_sprint
    before insert
    on sprints
    for each row
BEGIN
    IF EXISTS (
        SELECT 1
        FROM sprints
        WHERE IdEq = NEW.IdEq
          AND (
            (NEW.DateDebS BETWEEN DateDebS AND DateFinS)
                OR
            (NEW.DateFinS BETWEEN DateDebS AND DateFinS)
                OR
            (DateDebS BETWEEN NEW.DateDebS AND NEW.DateFinS)
            )
    ) THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Un autre sprint est déjà actif pour cette équipe dans cette période';
    END IF;
END;

