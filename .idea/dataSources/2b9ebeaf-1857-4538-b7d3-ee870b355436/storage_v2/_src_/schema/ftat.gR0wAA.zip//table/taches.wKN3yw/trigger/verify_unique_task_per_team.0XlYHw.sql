create definer = root@localhost trigger verify_unique_task_per_team
    before insert
    on taches
    for each row
BEGIN
    DECLARE task_count INT;
    
    SELECT COUNT(*) INTO task_count
    FROM taches
    WHERE TitreT = NEW.TitreT AND IdEq = NEW.IdEq;

    IF task_count > 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Erreur : Une tache avec ce titre existe déjà dans cette équipe.';
    END IF;
END;

